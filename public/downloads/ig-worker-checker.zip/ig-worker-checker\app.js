// IG Worker Checker page: for each user in the list, checks whether the worker
// account follows them and left comments on their recent posts.
// Instagram requests live in checker.js (shared with the admin bridge in background.js).

const $ = (id) => document.getElementById(id);
const els = {
  worker: $('worker'), posts: $('posts'), commentPages: $('commentPages'), delay: $('delay'),
  users: $('users'), onlyNew: $('onlyNew'),
  start: $('start'), stop: $('stop'), exportBtn: $('export'), clear: $('clear'),
  summary: $('summary'), progress: $('progress').firstElementChild, results: $('results'), log: $('log'),
};

let results = {};      // username -> result object
let order = [];        // usernames in display order
let running = false;
let stopRequested = false;

const checker = createIgChecker({
  getDelay: () => els.delay.value,
  log: (msg) => log(msg),
  isStopped: () => stopRequested,
});

function log(msg) {
  const t = new Date().toLocaleTimeString('ru-RU');
  els.log.textContent = `[${t}] ${msg}
` + els.log.textContent.slice(0, 20000);
}

const parseUsername = parseIgUsername;

const STATUS_RU = { 'account not found': 'аккаунт не найден', 'private account': 'закрытый профиль', 'no posts': 'нет постов' };
const statusRu = (s) => STATUS_RU[s] || s.replace(/^ok, posts:/, 'ок, постов:');

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function run() {
  const worker = parseUsername(els.worker.value);
  if (!worker) { alert('Укажите аккаунт воркера'); return; }
  const list = [...new Set(els.users.value.split(/\r?\n/).map(parseUsername).filter(Boolean))].filter((u) => u !== worker);
  if (!list.length) { alert('Список юзеров пуст'); return; }

  const queue = els.onlyNew.checked ? list.filter((u) => !results[u] || results[u].error) : list;
  list.forEach((u) => { if (!order.includes(u)) order.push(u); });
  render();
  if (!queue.length) { log('Все юзеры уже проверены'); return; }

  setRunning(true);
  saveSettings();
  const ctx = {
    worker,
    posts: Math.min(12, Math.max(0, Number(els.posts.value) || 0)),
    commentPages: Math.max(1, Number(els.commentPages.value) || 1),
    authors: new Set([worker]),
    follower: worker,
    following: null,
  };

  try {
    log(`Старт: воркер @${worker}, юзеров ${queue.length}`);
    const wp = await checker.getProfile(worker);
    if (!wp) throw new Error(`Аккаунт воркера @${worker} не найден`);
    if (!wp.is_private || wp.followed_by_viewer) ctx.following = await checker.getFollowing(wp.id);
    if (!ctx.following) log('Подписку проверяю через подписчиков каждого юзера');

    for (let i = 0; i < queue.length; i++) {
      const u = queue[i];
      setProgress(i, queue.length);
      try {
        results[u] = { ...(await checker.checkUser(u, ctx)), worker, checkedAt: new Date().toISOString() };
      } catch (e) {
        if (e instanceof IgLoginError || e instanceof IgStopError) throw e;
        results[u] = { username: u, follow: 'unknown', comments: [], status: 'ошибка: ' + e.message, error: true, worker };
      }
      log(`@${u}: подписка ${results[u].follow}, комментариев ${results[u].comments.length}`);
      await saveResults();
      render();
    }
    setProgress(1, 1);
    log('Готово');
  } catch (e) {
    if (e instanceof IgStopError) log('Остановлено');
    else if (e instanceof IgLoginError) { log('Instagram требует вход'); alert('Instagram просит войти. Откройте instagram.com в этом браузере, войдите в любой аккаунт и запустите снова.'); }
    else { log('Ошибка: ' + e.message); alert(e.message); }
  } finally {
    setRunning(false);
    render();
  }
}

// ---------- ui ----------

function setRunning(on) {
  running = on;
  stopRequested = false;
  els.start.disabled = on;
  els.stop.disabled = !on;
  els.clear.disabled = on;
}

function setProgress(done, total) {
  els.progress.style.width = `${Math.round((done / total) * 100)}%`;
}

const FOLLOW_LABEL = { yes: 'да', no: 'нет', unknown: '?' };

function render() {
  const rows = order.map((u, i) => {
    const r = results[u];
    if (!r) return `<tr><td>${i + 1}</td><td><a href="${IG_ORIGIN}/${u}/" target="_blank">@${u}</a></td><td>—</td><td>—</td><td>ожидает</td></tr>`;
    const comments = r.comments.length
      ? `<b>${r.comments.length}</b>` + r.comments.map((c) => `<div class="comment"><a href="${IG_ORIGIN}/p/${c.shortcode}/" target="_blank">пост</a>: ${escapeHtml(c.text)}</div>`).join('')
      : '<span class="no">0</span>';
    return `<tr><td>${i + 1}</td><td><a href="${IG_ORIGIN}/${u}/" target="_blank">@${u}</a></td>`
      + `<td class="${r.follow}">${FOLLOW_LABEL[r.follow]}</td><td>${comments}</td><td>${escapeHtml(statusRu(r.status))}</td></tr>`;
  });
  els.results.innerHTML = rows.join('');

  const done = order.filter((u) => results[u]);
  const followed = done.filter((u) => results[u].follow === 'yes').length;
  const commented = done.filter((u) => results[u].comments.length).length;
  const both = done.filter((u) => results[u].follow === 'yes' && results[u].comments.length).length;
  els.summary.textContent = order.length
    ? `Проверено ${done.length} из ${order.length} · подписан: ${followed} · с комментарием: ${commented} · и то и другое: ${both}`
    : 'Нет результатов';
  els.exportBtn.disabled = !done.length;
}

function exportCsv() {
  const q = (s) => `"${String(s).replace(/"/g, '""')}"`;
  const lines = [['username', 'подписка', 'комментариев', 'посты с комментарием', 'тексты', 'статус'].map(q).join(';')];
  for (const u of order) {
    const r = results[u];
    if (!r) continue;
    lines.push([
      u, FOLLOW_LABEL[r.follow], r.comments.length,
      [...new Set(r.comments.map((c) => `${IG_ORIGIN}/p/${c.shortcode}/`))].join(' '),
      r.comments.map((c) => c.text).join(" | "), statusRu(r.status),
    ].map(q).join(';'));
  }
  const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `ig-check-${parseUsername(els.worker.value) || 'worker'}-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- storage ----------

function saveSettings() {
  chrome.storage.local.set({
    settings: {
      worker: els.worker.value, posts: els.posts.value, commentPages: els.commentPages.value,
      delay: els.delay.value, users: els.users.value, onlyNew: els.onlyNew.checked,
    },
  });
}

function saveResults() {
  return chrome.storage.local.set({ results, order });
}

async function load() {
  const { settings, results: r, order: o } = await chrome.storage.local.get(['settings', 'results', 'order']);
  if (settings) {
    els.worker.value = settings.worker || '';
    els.posts.value = settings.posts || 3;
    els.commentPages.value = settings.commentPages || 3;
    els.delay.value = settings.delay || 2000;
    els.users.value = settings.users || '';
    els.onlyNew.checked = settings.onlyNew !== false;
  }
  results = r || {};
  order = o || [];
  render();
}

els.start.addEventListener('click', () => { if (!running) run(); });
els.stop.addEventListener('click', () => { stopRequested = true; });
els.exportBtn.addEventListener('click', exportCsv);
els.clear.addEventListener('click', async () => {
  if (!confirm('Удалить все результаты?')) return;
  results = {};
  order = [];
  await saveResults();
  render();
});
[els.worker, els.posts, els.commentPages, els.delay, els.users, els.onlyNew].forEach((el) => el.addEventListener('change', saveSettings));
els.worker.addEventListener('change', () => {
  // results for another worker are meaningless, warn instead of silently mixing
  const w = parseUsername(els.worker.value);
  if (Object.values(results).some((r) => r.worker && r.worker !== w)) log('Внимание: в таблице есть результаты для другого воркера. Нажмите «Очистить результаты».');
});

load();
