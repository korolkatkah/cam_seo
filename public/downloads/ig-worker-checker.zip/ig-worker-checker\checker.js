// Shared Instagram checking logic. Loaded by app.html (<script>) and by the
// service worker (importScripts), so it must stay a plain script without modules.
// All requests run inside an instagram.com tab (same origin), so the browser's
// existing Instagram session is used; the extension never handles credentials.

const IG_ORIGIN = 'https://www.instagram.com';
const IG_APP_ID = '936619743392459'; // public web app id sent by instagram.com itself

class IgLoginError extends Error {}
class IgStopError extends Error {}

function parseIgUsername(line) {
  let s = String(line || '').trim();
  if (!s) return null;
  const m = s.match(/instagram\.com\/([^/?#\s]+)/i);
  if (m) s = m[1];
  s = s.replace(/^@/, '').trim().toLowerCase();
  return /^[a-z0-9._]{1,30}$/.test(s) ? s : null;
}

function parseIgList(text) {
  return [...new Set(String(text || '').split(/[\r\n,;\t ]+/).map(parseIgUsername).filter(Boolean))];
}

// opts: { getDelay(): ms, log(msg), isStopped(): bool }
function createIgChecker(opts) {
  const log = opts.log || (() => {});
  let igTabId = null;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function pause(ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (opts.isStopped()) throw new IgStopError();
      await sleep(Math.min(500, end - Date.now()));
    }
  }

  function waitTabComplete(tabId, timeoutMs = 30000) {
    return new Promise((resolve) => {
      const done = () => { chrome.tabs.onUpdated.removeListener(listener); clearTimeout(timer); resolve(); };
      const listener = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
      const timer = setTimeout(done, timeoutMs);
      chrome.tabs.onUpdated.addListener(listener);
      chrome.tabs.get(tabId).then((t) => { if (t.status === 'complete') done(); }).catch(done);
    });
  }

  async function getIgTab() {
    if (igTabId !== null) {
      try {
        const t = await chrome.tabs.get(igTabId);
        if (t.url && t.url.startsWith(IG_ORIGIN)) return igTabId;
      } catch { /* tab was closed */ }
    }
    const tabs = await chrome.tabs.query({ url: IG_ORIGIN + '/*' });
    if (tabs.length) {
      igTabId = tabs[0].id;
    } else {
      log('Opening instagram.com in a background tab');
      const tab = await chrome.tabs.create({ url: IG_ORIGIN + '/', active: false });
      igTabId = tab.id;
    }
    await waitTabComplete(igTabId);
    return igTabId;
  }

  // Runs fetch() inside the instagram.com tab and returns { status, json, url }.
  async function igFetch(path) {
    const tabId = await getIgTab();
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId },
      args: [path, IG_APP_ID],
      func: async (path, appId) => {
        try {
          const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
          const r = await fetch(path, {
            credentials: 'include',
            headers: { 'X-IG-App-ID': appId, 'X-Requested-With': 'XMLHttpRequest', 'X-CSRFToken': csrf },
          });
          const text = await r.text();
          let json = null;
          try { json = JSON.parse(text); } catch { /* html login page etc. */ }
          return { status: r.status, json, url: r.url };
        } catch (e) {
          return { status: 0, json: null, error: String(e) };
        }
      },
    });
    return injection.result;
  }

  // GET with delay, rate-limit backoff and login detection. Returns json, or null on 404.
  async function api(path) {
    const baseDelay = Math.max(500, Number(opts.getDelay()) || 2000);
    for (let attempt = 1; attempt <= 4; attempt++) {
      await pause(baseDelay + Math.random() * baseDelay * 0.5);
      const r = await igFetch(path);
      const j = r.json;
      const msg = (j && j.message) || '';

      if (r.status === 200 && j && j.status !== 'fail') return j;
      if (r.status === 401 || (j && j.require_login) || (r.url || '').includes('/accounts/login') || msg === 'login_required') {
        throw new IgLoginError();
      }
      if (r.status === 404) return null;
      if (r.status === 429 || /wait|few minutes/i.test(msg) || r.status === 0) {
        const wait = 60000 * attempt;
        log(`Instagram rate limit (${r.status} ${msg}). Waiting ${wait / 1000} s`);
        await pause(wait);
        continue;
      }
      const err = new Error(`HTTP ${r.status}${msg ? ': ' + msg : ''}`);
      err.status = r.status;
      throw err;
    }
    throw new Error('Instagram rate limit did not clear after 4 attempts');
  }

  async function getProfile(username) {
    const j = await api(`/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`);
    return j && j.data && j.data.user ? j.data.user : null;
  }

  // Full following list of an account. Returns Set of usernames, or null if not accessible.
  async function getFollowing(userId) {
    const set = new Set();
    let maxId = '';
    for (let page = 0; page < 200; page++) {
      let j;
      try {
        j = await api(`/api/v1/friendships/${userId}/following/?count=200${maxId ? '&max_id=' + encodeURIComponent(maxId) : ''}`);
      } catch (e) {
        if (e instanceof IgLoginError || e instanceof IgStopError) throw e;
        log(`Following list not available (${e.message})`);
        return null;
      }
      if (!j || !Array.isArray(j.users)) return page === 0 ? null : set;
      j.users.forEach((u) => set.add(u.username.toLowerCase()));
      log(`Following list: ${set.size} loaded`);
      if (!j.next_max_id) break;
      maxId = j.next_max_id;
    }
    return set;
  }

  // Searches the target's followers for one username. Returns true/false, or null if not accessible.
  async function targetHasFollower(targetId, username) {
    const j = await api(`/api/v1/friendships/${targetId}/followers/?count=12&search_surface=follow_list_page&query=${encodeURIComponent(username)}`);
    if (!j || !Array.isArray(j.users)) return null;
    return j.users.some((u) => u.username.toLowerCase() === username);
  }

  // Comments on one post written by any of `authors` (Set). Stops early once every author is found.
  async function findComments(mediaId, authors, maxPages) {
    const found = [];
    const seen = new Set();
    let minId = '';
    for (let page = 0; page < maxPages; page++) {
      const j = await api(`/api/v1/media/${mediaId}/comments/?can_support_threading=true&permalink_enabled=false${minId ? '&min_id=' + encodeURIComponent(minId) : ''}`);
      if (!j) break;
      const take = (c) => {
        const name = c.user && c.user.username.toLowerCase();
        if (name && authors.has(name)) { found.push({ author: name, text: c.text }); seen.add(name); }
      };
      for (const c of j.comments || []) {
        take(c);
        (c.preview_child_comments || []).forEach(take);
      }
      if (seen.size >= authors.size || !j.has_more_comments || !j.next_min_id) break;
      minId = j.next_min_id;
    }
    return found;
  }

  // ctx: { authors: Set, posts, commentPages, follower?: string, following?: Set|null }
  // follow is 'yes' | 'no' | 'unknown', or 'skip' when ctx.follower is not set.
  async function checkUser(username, ctx) {
    const res = { username, follow: ctx.follower ? 'unknown' : 'skip', comments: [], postsChecked: 0, status: '' };
    const profile = await getProfile(username);
    if (!profile) { res.status = 'account not found'; return res; }

    const closed = profile.is_private && !profile.followed_by_viewer;

    if (ctx.follower) {
      if (ctx.following) {
        res.follow = ctx.following.has(username) ? 'yes' : 'no';
      } else if (!closed) {
        const has = await targetHasFollower(profile.id, ctx.follower);
        res.follow = has === null ? 'unknown' : has ? 'yes' : 'no';
      }
    }

    const edges = ((profile.edge_owner_to_timeline_media || {}).edges || []).slice(0, ctx.posts);
    if (closed && !edges.length) { res.status = 'private account'; return res; }
    if (!edges.length) { res.status = 'no posts'; return res; }

    for (const { node } of edges) {
      res.postsChecked++;
      if (!((node.edge_media_to_comment || {}).count)) continue;
      const found = await findComments(node.id, ctx.authors, ctx.commentPages);
      found.forEach((c) => res.comments.push({ ...c, shortcode: node.shortcode }));
    }
    res.status = `ok, posts: ${res.postsChecked}`;
    return res;
  }

  return { getProfile, getFollowing, targetHasFollower, findComments, checkUser };
}
