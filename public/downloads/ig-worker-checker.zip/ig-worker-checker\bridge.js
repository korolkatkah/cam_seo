// Content script on the EWO admin page: relays window.postMessage traffic between
// the page and the extension's service worker. Page messages carry `ewoIgc`,
// replies to the page carry `ewoIgcEvent`.

(() => {
  let port = null;

  const toPage = (event) => window.postMessage({ ewoIgcEvent: event }, window.location.origin);

  function connect() {
    port = chrome.runtime.connect({ name: 'ewo-igc' });
    port.onMessage.addListener(toPage);
    port.onDisconnect.addListener(() => {
      port = null;
      toPage({ type: 'disconnected' });
    });
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || !e.data.ewoIgc) return;
    const msg = e.data.ewoIgc;
    if (msg.type === 'ping') {
      toPage({ type: 'pong', version: chrome.runtime.getManifest().version });
      return;
    }
    if (msg.type === 'start' || msg.type === 'stop') {
      if (!port) connect();
      port.postMessage(msg);
    }
  });

  toPage({ type: 'pong', version: chrome.runtime.getManifest().version });
})();
