importScripts('checker.js');

// Clicking the toolbar icon opens the checker in a full tab (a popup closes too easily for long runs).
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('app.html');
  const [existing] = await chrome.tabs.query({ url });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});

// ---------- EWO admin bridge ----------
// bridge.js (content script on the admin page) opens a port named 'ewo-igc' and sends
// { type: 'start', authors, targets, posts, commentPages, delay } or { type: 'stop' }.
// Events back: { type: 'log' | 'result' | 'progress' | 'done' | 'error', ... }.

let adminRun = null; // { stop: bool }

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ewo-igc') return;
  let run = null;

  const send = (msg) => { try { port.postMessage(msg); } catch { /* page closed */ } };

  port.onDisconnect.addListener(() => { if (run) run.stop = true; });

  port.onMessage.addListener((msg) => {
    if (msg.type === 'stop') { if (run) run.stop = true; return; }
    if (msg.type !== 'start') return;
    if (adminRun) { send({ type: 'error', message: 'A check is already running in another admin tab' }); return; }
    run = adminRun = { stop: false };
    runAdminCheck(msg, run, send).finally(() => { if (adminRun === run) adminRun = null; });
  });
});

async function runAdminCheck(msg, run, send) {
  const authors = new Set(parseIgList((msg.authors || []).join('\n')));
  const targets = parseIgList((msg.targets || []).join('\n')).filter((u) => !authors.has(u));
  const log = (message) => send({ type: 'log', message });

  // Keeps the service worker alive through long rate-limit pauses.
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  const checker = createIgChecker({ getDelay: () => msg.delay, log, isStopped: () => run.stop });
  const ctx = {
    authors,
    posts: Math.min(12, Math.max(1, Number(msg.posts) || 3)),
    commentPages: Math.min(20, Math.max(1, Number(msg.commentPages) || 3)),
  };

  try {
    if (!authors.size) throw new Error('No commenter accounts');
    if (!targets.length) throw new Error('No accounts to check');
    log(`Start: ${targets.length} account(s), commenters: ${[...authors].map((a) => '@' + a).join(', ')}`);
    for (let i = 0; i < targets.length; i++) {
      const u = targets[i];
      send({ type: 'progress', done: i, total: targets.length, current: u });
      let res;
      try {
        res = await checker.checkUser(u, ctx);
      } catch (e) {
        if (e instanceof IgLoginError || e instanceof IgStopError) throw e;
        res = { username: u, comments: [], postsChecked: 0, status: 'error: ' + e.message, error: true };
      }
      res.checkedAt = new Date().toISOString();
      send({ type: 'result', result: res });
    }
    send({ type: 'progress', done: targets.length, total: targets.length });
    send({ type: 'done' });
  } catch (e) {
    if (e instanceof IgStopError) send({ type: 'done', stopped: true });
    else if (e instanceof IgLoginError) send({ type: 'error', message: 'Instagram asks to log in. Open instagram.com in this browser, log in to any account and start again.' });
    else send({ type: 'error', message: e.message });
  } finally {
    clearInterval(keepAlive);
  }
}
