# IG Worker Checker

Chrome extension: takes a list of Instagram users and checks, for each one, whether the worker account
follows them and left comments on their latest posts.

## Install

1. Open `chrome://extensions`, enable "Developer mode".
2. "Load unpacked" → select this folder (`D:\IG-WORKER-CHECKER`).
3. Click the extension icon — the checker opens in a new tab.

## How it works

- All requests run inside an `instagram.com` tab of the same browser (opened in the background if none is open),
  using the Instagram web API the site itself uses. The extension never asks for or stores a password.
- Instagram does not show follow lists or comments to anonymous visitors, so the browser must have
  **any** Instagram account signed in (not necessarily the worker's).
- **Follow check:** loads the worker's full following list once (works if the worker is public or followed by the
  signed-in account). Otherwise it searches each target's followers for the worker's username.
- **Comment check:** for each target, reads the N latest posts (max 12) and scans their comments
  (and preview replies) for the worker's username, up to "comment pages per post" pages.
- Results and settings are kept in `chrome.storage.local`; export to CSV (`;`-separated, UTF-8 BOM for Excel).

## EWO admin integration

`bridge.js` runs on `https://www.ewohub.com/cabinet/*` (and `localhost`). The admin "IG comments" tab sends
the commenter accounts and the database to the extension; `background.js` checks each account's latest posts
with `checker.js` and streams results back. Reload the admin page after installing or updating the extension.

## Limits

- Private targets not followed by the signed-in account: follow = `?` unless the worker's following list is available;
  comments cannot be checked.
- Instagram rate-limits aggressive use. Keep the delay at 2000 ms or more; on 429 the extension pauses 1–4 minutes
  and retries.
